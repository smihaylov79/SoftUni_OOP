from project.person import Person
class Child(Person):
    def __init__(self, name, age):
        self.name = name
        self.age = age