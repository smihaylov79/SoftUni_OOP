from project.dog import Dog
from project.cat import Cat

d=Dog()
c=Cat()
print(d.eat())
print(d.bark())

